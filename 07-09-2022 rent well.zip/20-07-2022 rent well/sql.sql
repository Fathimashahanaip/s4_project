/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 5.6.12-log : Database - rent_well
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`rent_well` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `rent_well`;

/*Table structure for table `bank` */

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank` varchar(25) DEFAULT NULL,
  `ifsc_code` varchar(25) DEFAULT NULL,
  `account` varchar(16) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL,
  `balance` int(35) DEFAULT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `bank` */

insert  into `bank`(`bank_id`,`bank`,`ifsc_code`,`account`,`password`,`balance`) values 
(1,'sbi','123','123456','123',2966675),
(2,'south indian','123','76543','98754',1003488);

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

/*Data for the table `cart` */

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `category` */

insert  into `category`(`category_id`,`category`) values 
(3,'dupatta'),
(9,'kerala sharvani'),
(11,'Lehenga');

/*Table structure for table `complaint` */

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `complaint` varchar(150) NOT NULL,
  `reply` varchar(150) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `complaint` */

insert  into `complaint`(`complaint_id`,`user_id`,`complaint`,`reply`,`date`,`status`,`owner_id`) values 
(1,3,'bad one','pending','2022-07-28','pending',2),
(2,3,'test','abc','2022-07-28','done',2),
(3,4,'Bad Service','pending','2022-07-30','pending',5),
(4,4,'Bad customer service','pending','2022-08-30','pending',5);

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`login_id`,`username`,`password`,`type`) values 
(1,'admin','admin','admin'),
(2,'nithu@gmail.com','nithu','owner'),
(3,'manu@gmail.com','manu','user'),
(4,'bushi@gmail.com','bushi','user'),
(5,'munnu@gmail.com','munnu','owner'),
(6,'maji@gmail.com','maji','pending');

/*Table structure for table `order` */

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `amount` float NOT NULL,
  `status` varchar(50) NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `owner_status` varchar(50) DEFAULT 'pending',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `order` */

insert  into `order`(`order_id`,`user_id`,`owner_id`,`date`,`amount`,`status`,`account_number`,`owner_status`) values 
(15,4,5,'2022-08-30',6800,'payment returned','','approved'),
(16,4,5,'2022-08-30',13600,'payment returned','123456','approved');

/*Table structure for table `order_sub` */

DROP TABLE IF EXISTS `order_sub`;

CREATE TABLE `order_sub` (
  `order_sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `amount` float NOT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`order_sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

/*Data for the table `order_sub` */

insert  into `order_sub`(`order_sub_id`,`order_id`,`product_id`,`amount`,`quantity`,`date`,`status`) values 
(22,15,3,5600,'1','0000-00-00','payment returned'),
(23,16,5,8000,'2','0000-00-00','payment returned'),
(24,16,3,5600,'1','0000-00-00','completed');

/*Table structure for table `owner` */

DROP TABLE IF EXISTS `owner`;

CREATE TABLE `owner` (
  `owner_id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_name` varchar(50) NOT NULL,
  `owner_image` varchar(200) NOT NULL,
  `phone` bigint(11) NOT NULL,
  `owner_email` varchar(50) NOT NULL,
  `login_id` int(11) NOT NULL,
  `house_name` varchar(50) NOT NULL,
  `place` varchar(50) NOT NULL,
  `pin` int(11) NOT NULL,
  `district` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `post` varchar(50) NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `owner` */

insert  into `owner`(`owner_id`,`owner_name`,`owner_image`,`phone`,`owner_email`,`login_id`,`house_name`,`place`,`pin`,`district`,`state`,`post`) values 
(1,'nithu','/static/owner/20220728151007.jpg',9544333819,'nithu@gmail.com',2,'valiyaparambil','poonoor',675432,'kozhikode','kerala','unnikulam'),
(2,'munnu','/static/owner/20220728200624.jpg',9544333819,'munnu@gmail.com',5,'illapoyil','kolikkal',673574,'kozhikode','kerala','unnikulam'),
(3,'MAJITHA FASIL','/static/owner/20220730120008.jpg',7654322765,'maji@gmail.com',6,'valiyaparambil','kolikkal',673574,'kozhikode','kerala','unnikulam');

/*Table structure for table `payment` */

DROP TABLE IF EXISTS `payment`;

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `amount` float NOT NULL,
  `date` date NOT NULL,
  `owner_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `account_number` int(11) NOT NULL,
  `ifsc_code` varchar(50) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `payment` */

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(50) NOT NULL,
  `product_image` varchar(200) NOT NULL,
  `rent` float NOT NULL,
  `category_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `product` */

insert  into `product`(`product_id`,`product_name`,`product_image`,`rent`,`category_id`,`owner_id`,`stock`) values 
(1,'Red','/static/owner/20220728152042.jpg',500,3,2,4),
(2,'Golden ','/static/owner/20220728152108.jpg',2000,6,2,2),
(3,'Red','/static/owner/20220728200901.jpg',2800,3,5,1),
(4,'white','/static/owner/20220728200835.jpg',2000,6,5,1),
(5,'Green ','/static/owner/20220830155846.jpg',2000,11,5,1);

/*Table structure for table `review` */

DROP TABLE IF EXISTS `review`;

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `review` varchar(150) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`review_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `review` */

insert  into `review`(`review_id`,`user_id`,`product_id`,`review`,`date`) values 
(1,3,1,'good one','2022-07-28'),
(2,3,1,'good','2022-07-28'),
(3,4,5,'Nice dress','2022-08-30');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `user_image` varchar(200) NOT NULL,
  `place` varchar(50) NOT NULL,
  `pin` int(11) NOT NULL,
  `post` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `phone` bigint(11) NOT NULL,
  `login_id` int(11) DEFAULT NULL,
  `house name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `id_card` varchar(200) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`user_id`,`user_name`,`user_email`,`gender`,`user_image`,`place`,`pin`,`post`,`district`,`state`,`phone`,`login_id`,`house name`,`password`,`id_card`) values 
(1,'manu','manu@gmail.com','Female','/static/user/20220728153234.jpg','kolikkal',765432,'unnikulam','kozhikode','kerala',3456789043,3,'valiyaparambil','','/static/user/20220727124953.jpg'),
(2,'bushra','bushi@gmail.com','Female','/static/user/20220730120641.jpg','kolikkal',673574,'unnikulam','kozhikode','kerala',9544333819,4,'valiyaparambil','','/static/user/20220728200452.jpg');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
